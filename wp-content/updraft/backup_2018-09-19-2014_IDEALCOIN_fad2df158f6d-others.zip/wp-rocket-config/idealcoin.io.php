<?php
defined( 'ABSPATH' ) or die( 'Cheatin\' uh?' );

$rocket_cookie_hash = '2548d15670173aa014d269a4ff8d3d3f';
$rocket_cache_mobile = '1';
$rocket_do_caching_mobile_files = '1';
$rocket_cache_ssl = '1';
$rocket_cache_reject_uri = '(.*)/feed/?|/wp-json/(.*)';
$rocket_cache_reject_cookies = 'wordpress_logged_in_|wp-postpass_|wptouch_switch_toggle|comment_author_|comment_author_email_';
$rocket_cache_reject_ua = 'facebookexternalhit';
$rocket_cache_query_strings = array (
);
$rocket_secret_cache_key = '5b5a4d1f979fd936516915';
$rocket_cache_mandatory_cookies = '';
$rocket_cache_dynamic_cookies = array (
);
