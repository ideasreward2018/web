<?php
/**
 * @package Blox Page Builder
 * @author UniteCMS.net
 * @copyright (C) 2017 Unite CMS, All Rights Reserved. 
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * */
defined('_JEXEC') or die('Restricted access');

class HtmlOutputBaseUC{
	
	const BR = "\n";
	const BR2 = "\n\n";
	const TAB = "	";
	const TAB2 = "		";
	const TAB3 = "			";
	const TAB4 = "				";
	const TAB5 = "					";
	const TAB6 = "						";
}