<?php

/**
 * provider addon
 */
class UniteCreatorAddon extends UniteCreatorAddonWork{
	
	
	
}